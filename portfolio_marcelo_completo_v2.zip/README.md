# Portfólio - Marcelo H. Ramos

Portfólio acadêmico e prático para Ciência de Dados.

## Conteúdo

- `index.html` - página principal
- `cases/` - páginas individuais dos projetos
- `assets/` - visuais reais extraídos dos projetos disponíveis localmente
- `Curriculo_Marcelo_H_Ramos.pdf` - currículo em PDF
- `DataSet_Tab_Fipe_Final(11).ipynb` - notebook da Tabela FIPE
- `V2-finalProjeto_Inspirar.pbix` - arquivo Power BI
- `Database Opinate.sql` - banco MySQL

## Publicação no GitHub Pages

1. Crie um repositório público (ex.: `portfolio`).
2. Envie todo o conteúdo desta pasta para a raiz da branch `main`.
3. Vá em `Settings` -> `Pages`.
4. Em Build and deployment, selecione `Deploy from a branch`.
5. Escolha `main` e `/root`.
6. Salve e aguarde a URL do GitHub Pages.

## Antes de divulgar

Atualize a seção Contato do `index.html` com seu LinkedIn e e-mail profissional. Também vale criar um repositório individual para cada projeto e substituir os links dos arquivos locais por links para esses repositórios.

## Observação sobre screenshots

O notebook e o arquivo PBIX fornecidos permitiram inserir visuais reais no portfólio. As aplicações externas (Streamlit e GitHub Pages) ficaram com previews de navegador e links live, pois o ambiente de execução não conseguiu recuperar suas páginas para captura de tela.
